// import {Counter} from "./component/Counter";
import "./App.css";
import { Todo } from "./component/Todo";


function App() {

  return <div>
    {/* <Counter /> */}
    <Todo />
  </div>;
}

export default App;
